name = 'Alex'
print('Name:',name)
age = 22
print('Age:', age)
age = age + 1
print('New Age:', age)
is_student = True
print('Is Student', is_student)